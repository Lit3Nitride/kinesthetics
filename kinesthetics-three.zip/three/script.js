/* ================ Setting up the 3D scene ================ */
//                                                           //
//   DO NOT CHANGE THE VARIABLE NAMES IF USING addToState(0.)  //
//                                                           //
/* ========================================================= */
var scene = new THREE.Scene(),
    renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      preserveDrawingBuffer: true
    })
    camera = new THREE.PerspectiveCamera(35, aspect, 0.1, 20000)

renderer.setPixelRatio(window.devicePixelRatio)
renderer.setClearColor(0x000000, 0)

function onSlideResize(width, height) {
  camera.aspect = aspect
  camera.updateProjectionMatrix()
  renderer.setSize(width, height)
}

/* ========================================================== */
/* ============== Done Setting up the 3D scene ============== */
/* ========================================================== */

// Add canvas to slide.
// Uncomment the line below if your slide name is "3D"

// document.getElementById("3D").appendChild(renderer.domElement)


/* ===================================== */
/* ============== Lights! ============== */
/* ===================================== */

/*
var lights = []
lights[0] = new THREE.SpotLight(0xffffff, .15, 0)
lights[1] = new THREE.SpotLight(0xffffff, .05, 0)
lights[2] = new THREE.SpotLight(0xffffff, .25, 0)

lights[0].position.set(0, 1000, 0)
lights[1].position.set(100, 1000, 150)
lights[2].position.set(-50, -200, -100)

for (var i=0; i<lights.length; i++) {
  lights[i].castShadow = true
  scene.add(lights[i])
}
*/

/* ===================================== */
/* ============== Shapes! ============== */
/* ===================================== */


/* ===================================== */
/* ============== States! ============== */
/* ===================================== */

